const bcrypt=require('bcryptjs'); const db=require('./db');
const email=process.env.ADMIN_EMAIL||'admin@expressservicerequest.com'; const password=process.env.ADMIN_PASSWORD||'ChangeMeImmediately!';
const hash=bcrypt.hashSync(password,12);
const exists=db.prepare('SELECT id FROM users WHERE email=?').get(email);
if(exists) db.prepare('UPDATE users SET password_hash=?, role=\'admin\' WHERE id=?').run(hash,exists.id);
else db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,\'admin\')').run('ESR Administrator',email,hash);
console.log(`Admin ready: ${email}`); console.log('Change the password before production use.');
