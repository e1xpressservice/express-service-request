# Express Service Request (ESR) — Deployable Operations Package

This package upgrades the original front-end prototype into a Node.js/Express application with a SQLite operations database, customer login foundation, admin API, shipment request workflow, quote records, shipment records, tracking events, document upload storage, audit logs, security middleware and a responsive public website.

## Business details configured
- Business: Express Service Request (ESR)
- Website domain intended: expressservicerequest.com
- Email: expressservicerequest@gmail.com
- Turkey address: S. Gökçen Hava Kargo Terminal, 34906 Istanbul, Turkey
- Yemen branch: Khor Maksar, Aden, Yemen

## Run locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Set environment variables from `.env.example`.
4. Set a strong `SESSION_SECRET`.
5. Set `ADMIN_EMAIL` and a strong `ADMIN_PASSWORD`.
6. Run `npm run seed-admin` once.
7. Run `npm start`.
8. Open `http://localhost:3000`.

## Production requirements before accepting real customer data
- Deploy behind HTTPS/TLS.
- Use a strong secret and production admin password.
- Put SQLite on persistent storage or migrate the DB layer to PostgreSQL for multi-instance hosting.
- Move uploaded documents to private object storage with access-controlled download endpoints.
- Configure SMTP for customer/admin email notifications.
- Add a dedicated production domain and DNS records.
- Configure backups, monitoring and log retention.
- Add CAPTCHA/anti-abuse controls as needed.
- Review privacy, retention, customs, insurance and shipping-restriction terms with qualified counsel/operations staff.
- Do not claim carrier partnerships, customs authority, certifications or licenses unless separately verified.

## Operational model
Request → Review → Quote → Customer approval → Booking → Cargo received → Documentation → In transit → Arrived → Out for delivery → Delivered.

The ESR request number is an internal request reference. It is not an airline AWB, bill of lading, customs reference or carrier tracking number. Carrier references can be stored separately when supplied.

## Important
This package contains the application source and is deployable, but this chat environment does not itself publish it to the public internet or connect your DNS. A hosting account/server is still required to put the application online.

## Admin console
Open `/admin` after logging in through `/api/login` with the seeded admin account. The console lists requests and shipments, changes request status, creates basic quotes, and adds tracking events. For production, replace prompt-based quote/event entry with the full internal form and connect transactional email.

## Current scope
The included package is an operational foundation, not a claim that a hosting provider, DNS, email account, carrier API or customs system has already been connected. Those external credentials and accounts must be supplied by the business.
